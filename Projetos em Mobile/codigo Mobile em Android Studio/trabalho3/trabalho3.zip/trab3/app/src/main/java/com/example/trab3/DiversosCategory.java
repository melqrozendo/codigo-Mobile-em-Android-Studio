package com.example.trab3;

import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.content.Intent;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class DiversosCategory extends ListActivity{

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ListView listDiversos = getListView();
        ArrayAdapter<Diversos> listAdapter = new ArrayAdapter<Diversos>
                (this, android.R.layout.simple_list_item_1, Diversos.consoles);
        listDiversos.setAdapter(listAdapter);


    }
    public void onListItemClick(ListView listView, View itemView, int position, long id){
        Intent intent = new Intent(DiversosCategory.this, DiversosDetalhes.class);
        intent.putExtra(DiversosDetalhes.EXTRA_CONSOLENO, (int) id);
        startActivity(intent);
    }
}


