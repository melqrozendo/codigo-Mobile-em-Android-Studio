package com.example.trab3;

public class Destilados {
    private String name;
    private static String description;
    private int imageResourceId;

    public static final Destilados[] consoles = new Destilados[]{
            new Destilados("ABSOLUT", "Absolut é uma marca de vodka sueca fundada em 1879 por L.O. Smith na pequena cidade sueca de Åhus. Revolucionou a fabricação de vodka por meio do processo de destilação contínua.", R.drawable.absolut),
            new Destilados("JACK DANIELS", "Jack Daniel's é um uísque fabricado pela Jack Daniel Distillery, fundada em 1876 pelo destilador norte-americano Jack Daniel, com sede na cidade de Lynchburg, Tennessee, Estados Unidos da América.", R.drawable.jackdaniels),
            new Destilados("BOMBAY SAPPHIRE", "Bombay Sapphire é uma marca de gin lançada pela primeira vez em 1986 pelo comerciante de vinhos inglês IDV", R.drawable.bombay),
    };

    private Destilados(String name, String description, int imageResourceId) {
        this.name = name;
        this.description = description;
        this.imageResourceId = imageResourceId;
    }

    public String getName() { return name; }

    public static String getDescription() { return description; }

    public int getImageResourceId() { return imageResourceId; }

    public String toString() { return this.name; }
}
