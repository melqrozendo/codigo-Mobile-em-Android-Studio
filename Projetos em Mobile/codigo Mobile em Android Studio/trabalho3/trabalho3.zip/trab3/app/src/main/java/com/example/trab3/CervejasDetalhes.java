package com.example.trab3;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class CervejasDetalhes extends AppCompatActivity {
    public static final String EXTRA_CONSOLENO = "consoleNo";

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cervejas_detalhes);

        int consoleNo = (Integer)getIntent().getExtras().get(EXTRA_CONSOLENO);
        Cervejas cervejas = Cervejas.consoles[consoleNo];


        ImageView photo = findViewById(R.id.photo);
        photo.setImageResource(cervejas.getImageResourceId());
        photo.setContentDescription(cervejas.getName());

        TextView name = findViewById(R.id.name);
        name.setText(cervejas.getName());

        TextView description = findViewById(R.id.description);
        description.setText(cervejas.getDescription());
    }
}
