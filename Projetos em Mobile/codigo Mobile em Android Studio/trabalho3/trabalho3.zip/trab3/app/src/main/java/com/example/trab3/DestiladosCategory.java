package com.example.trab3;

import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.content.Intent;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class DestiladosCategory extends ListActivity {


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ListView listDestilados = getListView();
        ArrayAdapter<Destilados> listAdapter = new ArrayAdapter<Destilados>(
                this, android.R.layout.simple_list_item_1, Destilados.consoles);
        listDestilados.setAdapter(listAdapter);




    }
    public void onListItemClick(ListView listView, View itemView, int position, long id){
        Intent intent = new Intent(DestiladosCategory.this, DestiladosDetalhes.class);
        intent.putExtra(DestiladosDetalhes.EXTRA_CONSOLENO, (int) id);
        startActivity(intent);
    }
}
