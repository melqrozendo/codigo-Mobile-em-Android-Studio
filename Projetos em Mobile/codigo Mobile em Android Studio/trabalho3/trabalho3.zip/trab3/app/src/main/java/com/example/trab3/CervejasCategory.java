package com.example.trab3;

import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.content.Intent;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class CervejasCategory extends ListActivity {


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ListView listCervejas = getListView();
        ArrayAdapter<Cervejas> listAdapter = new ArrayAdapter<Cervejas>(
                this, android.R.layout.simple_list_item_1, Cervejas.consoles);
        listCervejas.setAdapter(listAdapter);




    }
public void onListItemClick(ListView listView, View itemView, int position, long id){
        Intent intent = new Intent(CervejasCategory.this, CervejasDetalhes.class);
        intent.putExtra(CervejasDetalhes.EXTRA_CONSOLENO, (int) id);
        startActivity(intent);
    }
}
