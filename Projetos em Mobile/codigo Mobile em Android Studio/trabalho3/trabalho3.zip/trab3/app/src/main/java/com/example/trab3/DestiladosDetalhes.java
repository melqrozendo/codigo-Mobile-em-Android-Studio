package com.example.trab3;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DestiladosDetalhes extends AppCompatActivity {
    public static final String EXTRA_CONSOLENO = "consoleNo";

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cervejas_detalhes);

        int consoleNo = (Integer)getIntent().getExtras().get(EXTRA_CONSOLENO);
        Destilados destilados = Destilados.consoles[consoleNo];


        ImageView photo = findViewById(R.id.photo);
        photo.setImageResource(destilados.getImageResourceId());
        photo.setContentDescription(destilados.getName());

        TextView name = findViewById(R.id.name);
        name.setText(destilados.getName());

        TextView description = findViewById(R.id.description);
        description.setText(destilados.getDescription());
    }
}
